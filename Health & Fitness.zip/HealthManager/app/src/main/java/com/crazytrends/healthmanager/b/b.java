package com.crazytrends.healthmanager.b;

import android.speech.tts.TextToSpeech.OnInitListener;

import com.crazytrends.healthmanager.general.MyApplication;


/* compiled from: lambda */
public final /* synthetic */ class b implements OnInitListener {


    private final /* synthetic */ MyApplication f9a;

    public /* synthetic */ b(MyApplication absWomenApplication) {
        this.f9a = absWomenApplication;
    }

    public final void onInit(int i) {
        this.f9a.a(i);
    }
}
