package com.crazytrends.healthmanager;

import android.view.View;

/* compiled from: lambda */
public final /* synthetic */ class f implements View.OnClickListener {


    private final /* synthetic */ MainExcerciseActivity f5a;

    public /* synthetic */ f(MainExcerciseActivity mainExcerciseActivity) {
        this.f5a = mainExcerciseActivity;
    }

    public final void onClick(View view) {
        this.f5a.a(view);
    }
}
