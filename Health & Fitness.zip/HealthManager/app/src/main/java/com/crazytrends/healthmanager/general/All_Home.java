package com.crazytrends.healthmanager.general;

public class All_Home {

    int f2614id;
    String image;
    String title;

    public All_Home(int i, String str, String str2) {
        this.f2614id = i;
        this.title = str;

        this.image = str2;
    }
}
