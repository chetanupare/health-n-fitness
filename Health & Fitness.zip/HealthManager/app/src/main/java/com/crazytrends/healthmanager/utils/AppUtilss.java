package com.crazytrends.healthmanager.utils;

public class AppUtilss {
    public static String KEY_PROGRESS = "weightlossProgress";
    public static String WORKOUT_BROADCAST_FILTER = "com.android.weightloss";
}
